/*
SQLyog Community v12.5.0 (64 bit)
MySQL - 5.0.67-community-nt : Database - tutoring
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`tutoring` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `tutoring`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `uname` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

insert  into `admin`(`uname`,`password`) values 
('Bhagwan','bhagwan');

/*Table structure for table `answers` */

DROP TABLE IF EXISTS `answers`;

CREATE TABLE `answers` (
  `answer_id` int(11) NOT NULL auto_increment,
  `exam_id` int(11) NOT NULL,
  `question` varchar(100) NOT NULL,
  `answer` varchar(100) NOT NULL,
  `correct_answer` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY  (`answer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8;

/*Data for the table `answers` */

insert  into `answers`(`answer_id`,`exam_id`,`question`,`answer`,`correct_answer`,`status`) values 
(79,47,' Which of these methods of a Thread class is used to suspend a thread for a period of time?',' sleep()','sleep()','incorrect'),
(80,47,' Which of these is necessary to specify at time of array initialization?','Row','Row','correct'),
(81,47,' Which of these is a process of converting a simple data type into a class?',' type casting','type wrapping','incorrect'),
(82,47,'Which of this method of class String is used to obtain a length of String object?',' get()',' length()','incorrect'),
(83,47,' What is the range of short data type in Java?','-32768 to 32767',' -32768 to 32767','incorrect'),
(84,47,'Which of these class is used to make a thread?','Runnable','Thread','incorrect'),
(85,47,'Which of these class is superclass of every class in Java?',' Object class','Object class','incorrect'),
(86,47,'Which of these method of Object class can clone an object?','Object clone()','Object clone()','correct'),
(87,47,'Classes and Methods are stored in which space?','Permanent space',' Permanent space','incorrect'),
(88,47,' Which of these is long data type literal?',' 0x99fffL','0x99fffL','incorrect'),
(89,47,'Which of these methods is used to add elements in vector at specific location?','addElement()','addElement()','correct'),
(90,47,'Which of these class relies upon its subclasses for complete implementation of its methods?','Object class','abstract class','incorrect'),
(91,47,'Which of the following is not a memory classification in java?','Young','Temporary','incorrect'),
(92,47,' Which of the following is a method having same name as that of itÃ¢??s class?','constructor','constructor','correct'),
(93,47,' What is the return type of a method that does not return any value?','double',' void','incorrect'),
(94,47,'Which of these methods is used to check for infinitely large and small values?',' isInfinite()',' isInfinite()','correct'),
(95,47,'What is JVM?','Extension',' Interpreter','incorrect'),
(96,47,'What is it called where child object gets killed if parent object is killed?','Association',' Composition','incorrect'),
(97,47,'Which data type value is returned by all transcendental math functions?',' long',' double','incorrect'),
(98,47,'Which of these operators is used to allocate memory to array variable in Java?',' new malloc','new','incorrect'),
(99,47,'Which of these keywords can be used to prevent inheritance of a class?','super',' final','incorrect'),
(100,47,'What is the Java 8 update of PermGen?','Metaspace','Metaspace','correct'),
(101,47,'Which of these class is superclass of String and StringBuffer class?',' java.lang',' java.lang','correct'),
(102,47,' Which of these classes is not included in java.lang?','Array','Array','correct'),
(103,47,' Which of these keywords is used to make a class?',' class',' class','correct'),
(104,47,'Which of these keywords cannot be used for a class which has been declared final?','abstract and extends','abstract','incorrect'),
(105,47,' Which of these selection statements test only for equality?',' if','switch','incorrect'),
(106,47,' Which of the below is invalid identifier with the main method?','static',' private','incorrect'),
(107,47,' Which of the following is not OOPS concept in Java?',' Compilation',' Compilation','correct'),
(108,47,'Which of these are selection statements in Java?','if()','if()','correct'),
(109,47,'Which of these is an incorrect array declaration?',' int arr[] = int [5] new','int arr[] = int [5] new','incorrect'),
(110,47,'Which of these is a wrapper for simple data type float?',' Float',' Float','correct'),
(111,47,'Which of these class object can be used to form a dynamic array?','ArrayList',' ArrayList & Vector','incorrect'),
(112,47,'Which one of the following is a class loader?','Compiler','Bootstrap','incorrect'),
(113,47,'Which of these is the interface of legacy?',' Enumeration','Enumeration','incorrect'),
(114,47,'Which of the following is not a segment of memory in java?','Stack Segment','Register Segment','incorrect'),
(115,47,'Which of these are legacy classes?','Hashtable','All of the mentioned','incorrect'),
(116,47,'Which of these methods must be made static?',' finalize()','main()','incorrect'),
(117,47,'Arrays in Java are implemented as?',' variable','object','incorrect'),
(118,47,' What is it called if an object has its own lifecycle and there is no owner?','Association','Association','correct'),
(119,47,'Which of the following package stores all the simple data types in java?','java','lang','incorrect'),
(120,47,' Which component is used to compile, debug and execute java program?',' JDK',' JDK','correct'),
(121,47,'Which of this interface is implemented by Thread class?','Runnable','Runnable','correct'),
(122,47,'When does method overloading is determined?','At compile time','At compile time','correct'),
(123,47,'Which of these can be returned by the operator &?','Integer','Integer or Boolean','incorrect'),
(124,47,' Which of these can not be used for a variable name in Java?',' identifier',' keyword','incorrect'),
(125,47,' An expression involving byte, int, and literal numbers is promoted to which of these?','byte','int','incorrect'),
(126,47,'Which of these is a super class of wrappers Double & Integer?','Number',' Number','incorrect'),
(127,47,' Which of these cannot be declared static?',' object',' object','correct'),
(128,47,' What is the extension of java code files?',' .java',' .java','correct');

/*Table structure for table `courses` */

DROP TABLE IF EXISTS `courses`;

CREATE TABLE `courses` (
  `course_name` varchar(25) NOT NULL,
  `total_marks` int(11) NOT NULL,
  `time` varchar(45) NOT NULL,
  PRIMARY KEY  (`course_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `courses` */

insert  into `courses`(`course_name`,`total_marks`,`time`) values 
('Java',50,'60');

/*Table structure for table `exams` */

DROP TABLE IF EXISTS `exams`;

CREATE TABLE `exams` (
  `exam_id` int(11) NOT NULL auto_increment,
  `std_id` varchar(45) NOT NULL,
  `course_name` varchar(45) NOT NULL,
  `total_marks` varchar(45) NOT NULL,
  `obt_marks` varchar(45) default NULL,
  `date` varchar(45) NOT NULL,
  `start_time` varchar(45) NOT NULL,
  `end_time` varchar(45) default NULL,
  `exam_time` varchar(45) default NULL,
  `status` varchar(45) default NULL,
  PRIMARY KEY  (`exam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

/*Data for the table `exams` */

insert  into `exams`(`exam_id`,`std_id`,`course_name`,`total_marks`,`obt_marks`,`date`,`start_time`,`end_time`,`exam_time`,`status`) values 
(47,'6','Java','50','18','10-12-2018','20:17:13.703','20:20:28.096','60','Fail'),
(48,'6','Java','50',NULL,'10-12-2018','22:07:04.810',NULL,'60',NULL);

/*Table structure for table `questions` */

DROP TABLE IF EXISTS `questions`;

CREATE TABLE `questions` (
  `question_id` int(11) NOT NULL auto_increment,
  `course_name` varchar(45) NOT NULL,
  `question` varchar(255) NOT NULL,
  `opt1` varchar(100) NOT NULL,
  `opt2` varchar(100) NOT NULL,
  `opt3` varchar(100) NOT NULL,
  `opt4` varchar(100) NOT NULL,
  `correct` varchar(100) NOT NULL,
  PRIMARY KEY  (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

/*Data for the table `questions` */

insert  into `questions`(`question_id`,`course_name`,`question`,`opt1`,`opt2`,`opt3`,`opt4`,`correct`) values 
(10,'Java',' An expression involving byte, int, and literal numbers is promoted to which of these?','int','long','byte','float','int'),
(11,'Java','Which data type value is returned by all transcendental math functions?','int','float','double',' long',' double'),
(12,'Java',' What is the range of short data type in Java?','-128 to 127','-32768 to 32767',' -2147483648 to 2147483647','None of the mentioned',' -32768 to 32767'),
(13,'Java','Which of these operators is used to allocate memory to array variable in Java?','malloc','alloc','new',' new malloc','new'),
(14,'Java','Which of these is an incorrect array declaration?','int arr[] = new int[5]',' int [] arr = new int[5]',' int arr[] = new int[5]',' int arr[] = int [5] new','int arr[] = int [5] new'),
(15,'Java',' Which of these is necessary to specify at time of array initialization?','Row','Column',' Both Row and Column','None of the mentioned','Row'),
(16,'Java',' Which of these is long data type literal?',' 0x99fffL','ABCDEFG','0x99fffa',' 99671246','0x99fffL'),
(17,'Java','Which of these can be returned by the operator &?','Integer',' Boolean','Character','Integer or Boolean','Integer or Boolean'),
(18,'Java',' Which of these can not be used for a variable name in Java?',' identifier','keyword',' identifier & keyword','none of the mentioned',' keyword'),
(19,'Java',' Which component is used to compile, debug and execute java program?','JVM',' JDK','JIT',' JRE',' JDK'),
(20,'Java',' Which of the below is invalid identifier with the main method?','public','static',' private','final',' private'),
(21,'Java',' What is the extension of java code files?','.class',' .java','.txt','.js',' .java'),
(22,'Java',' Which of these keywords is used to make a class?',' class',' struct',' int','none of the mentioned',' class'),
(23,'Java',' What is the return type of a method that does not return any value?',' int',' float',' void','double',' void'),
(24,'Java',' Which of the following is a method having same name as that of itâ??s class?',' finalize',' delete','class','constructor','constructor'),
(25,'Java',' Which of these selection statements test only for equality?',' if',' switch',' if & switch','none of the mentioned','switch'),
(26,'Java','Which of these are selection statements in Java?','if()','for()','continue','break','if()'),
(27,'Java',' Which of the following is not OOPS concept in Java?','Inheritance','Encapsulation','Polymorphism',' Compilation',' Compilation'),
(28,'Java','When does method overloading is determined?',' At run time','At compile time','At coding time','At execution time','At compile time'),
(29,'Java',' What is it called if an object has its own lifecycle and there is no owner?',' Aggregation','Composition',' Encapsulation','Association','Association'),
(30,'Java','What is it called where child object gets killed if parent object is killed?',' Aggregation','Composition','Encapsulation','Association',' Composition'),
(31,'Java',' Which of these classes is not included in java.lang?','Byte',' Integer','Array','Class','Array'),
(32,'Java',' Which of these is a process of converting a simple data type into a class?',' type wrapping','type conversion',' type casting','none of the Mentioned','type wrapping'),
(33,'Java','Which of these is a super class of wrappers Double & Integer?','Long','Digits',' Float','Number',' Number'),
(34,'Java','Which of these is a wrapper for simple data type float?',' float','double',' Float',' Double',' Float'),
(35,'Java','Which of these methods is used to check for infinitely large and small values?',' isInfinite()','isNaN()',' Isinfinite()','IsNaN()',' isInfinite()'),
(36,'Java','Which of the following package stores all the simple data types in java?',' lang','java',' util',' java.packages','lang'),
(37,'Java','Which of these class is superclass of every class in Java?',' String class',' Object class','Abstract class','ArrayList class','Object class'),
(38,'Java','Which of these method of Object class can clone an object?','Objectcopy()','copy()','Object clone()','clone()','Object clone()'),
(39,'Java','Which of these keywords can be used to prevent inheritance of a class?','super','constant',' class',' final',' final'),
(40,'Java','Which of these keywords cannot be used for a class which has been declared final?','abstract','extends','abstract and extends','none of the mentioned','abstract'),
(41,'Java','Which of these class relies upon its subclasses for complete implementation of its methods?','Object class',' abstract class','ArrayList class','None of the mentioned','abstract class'),
(42,'Java','Arrays in Java are implemented as?','class',' object',' variable',' none of the mentioned','object'),
(43,'Java',' Which of these cannot be declared static?','class',' object','variable','method',' object'),
(44,'Java','Which of these methods must be made static?','main()','delete()',' run()',' finalize()','main()'),
(45,'Java','Which of the following is not a segment of memory in java?','Stack Segment',' Heap Segment','Code Segment','Register Segment','Register Segment'),
(46,'Java','What is JVM?','Bootstrap','Interpreter','Extension',' Compiler',' Interpreter'),
(47,'Java','Which one of the following is a class loader?','Bootstrap','Compiler','Heap','Interpreter','Bootstrap'),
(48,'Java','Which of the following is not a memory classification in java?','Young','Old','Permanent',' Temporary','Temporary'),
(49,'Java','What is the Java 8 update of PermGen?',' Code Cache','Tenured Space','Metaspace','Eden space','Metaspace'),
(50,'Java','Classes and Methods are stored in which space?','Eden space','Survivor space','Tenured space','Permanent space',' Permanent space'),
(51,'Java','Which of these class object can be used to form a dynamic array?','ArrayList','Map',' Vector',' ArrayList & Vector',' ArrayList & Vector'),
(52,'Java','Which of these are legacy classes?','Stack','Hashtable','Vector','All of the mentioned','All of the mentioned'),
(53,'Java','Which of these is the interface of legacy?','Map',' Enumeration',' HashMap','Hashtable','Enumeration'),
(54,'Java','Which of these methods is used to add elements in vector at specific location?',' add()','set()',' AddElement()','addElement()','addElement()'),
(55,'Java','Which of these class is used to make a thread?',' String',' System','Thread','Runnable','Thread'),
(56,'Java','Which of this interface is implemented by Thread class?','Runnable','Connections','Set','MapConnections','Runnable'),
(57,'Java',' Which of these methods of a Thread class is used to suspend a thread for a period of time?',' sleep()',' terminate()','suspend()','stop()','sleep()'),
(58,'Java','Which of these class is superclass of String and StringBuffer class?','java.util',' java.lang','ArrayList','None of the mentioned',' java.lang'),
(59,'Java','Which of this method of class String is used to obtain a length of String object?',' get()','Sizeof()','lengthof()',' length()',' length()');

/*Table structure for table `test` */

DROP TABLE IF EXISTS `test`;

CREATE TABLE `test` (
  `name` varchar(25) NOT NULL,
  `age` int(11) default NULL,
  PRIMARY KEY  (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `test` */

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL auto_increment,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) default NULL,
  `user_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `user_type` varchar(45) NOT NULL,
  `contact_no` varchar(45) default NULL,
  `city` varchar(45) default NULL,
  `address` varchar(45) default NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='		';

/*Data for the table `users` */

insert  into `users`(`user_id`,`first_name`,`last_name`,`user_name`,`email`,`password`,`user_type`,`contact_no`,`city`,`address`) values 
(1,'Bhagwan','Kharat','bhagwan','bhagwan2551@gmail.com','admin@123','admin','9970691125','pune','warje malwadi'),
(6,'prem','aru','prem','bhagwankharat4@gmail.com','prem@123','student','9970691125','Bangalore','warje malwadi');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
